<?php
namespace IMSGlobal\Caliper\entities\w3c;

interface Status {
}    
