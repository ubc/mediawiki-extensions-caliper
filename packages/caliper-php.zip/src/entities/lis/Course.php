<?php
namespace IMSGlobal\Caliper\entities\lis;

interface Course extends \IMSGlobal\Caliper\entities\w3c\Organization {
}
