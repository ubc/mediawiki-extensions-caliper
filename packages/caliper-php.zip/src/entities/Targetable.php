<?php
namespace IMSGlobal\Caliper\entities;

interface Targetable {
}