<?php
namespace IMSGlobal\Caliper\entities;

interface Generatable {
}