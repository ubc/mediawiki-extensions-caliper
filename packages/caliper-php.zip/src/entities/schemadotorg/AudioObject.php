<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface AudioObject extends MediaObject {
}
