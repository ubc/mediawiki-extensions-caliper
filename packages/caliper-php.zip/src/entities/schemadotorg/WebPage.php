<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface WebPage extends CreativeWork {
}
