<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface SoftwareApplication {
}    
