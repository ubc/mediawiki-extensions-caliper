<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

/**
 * From https://schema.org/Thing
 *
 * The most generic type of item
 */
interface Thing {
}