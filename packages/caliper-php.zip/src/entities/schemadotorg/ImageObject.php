<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface ImageObject extends MediaObject {
}
