<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface MediaObject extends CreativeWork {
}
