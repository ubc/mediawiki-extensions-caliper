<?php
namespace IMSGlobal\Caliper\entities\schemadotorg;

interface VideoObject extends MediaObject {
}
